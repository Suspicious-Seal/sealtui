"""
sealtui
a package for easily creating cli's and tui's.
"""

__version__ = "0.1.0"
__author__ = "Matthew Carmichael"
