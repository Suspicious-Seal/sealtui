class SealStyleInvalid(Exception):
    pass

class SealStyleSyntaxError(Exception):
    pass

class SealStyleNotFoundError(Exception):
    pass

class SealStyleArgumentsInvalidError(Exception):
    pass
